import {ChangeDetectionStrategy, Component, signal} from '@angular/core';
import {NgClass} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';

interface MenuItem {
  name: string;
  price: number;
}

interface MenuCategory {
  title: string;
  items: MenuItem[];
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [NgClass, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  isMenuOpen = signal(false);

  toggleMenu() {
    this.isMenuOpen.update(v => !v);
  }

  menuCategories: MenuCategory[] = [
    {
      title: 'Chai Chahiye?',
      items: [
        { name: 'Karak Chai', price: 130 },
        { name: 'Ilachi Chai', price: 150 },
        { name: 'Gurr Wali Chai', price: 150 },
        { name: 'Masala Chai', price: 170 },
        { name: 'Green Tea', price: 150 },
        { name: 'Herbal Tea', price: 150 },
      ]
    },
    {
      title: 'Hot Coffee',
      items: [
        { name: 'Americano', price: 280 },
        { name: 'Cappuccino', price: 310 },
        { name: 'Latte', price: 310 },
        { name: 'Mocha', price: 330 },
        { name: 'Hot Chocolate', price: 350 },
      ]
    },
    {
      title: 'Meetha...',
      items: [
        { name: 'French Toast', price: 400 },
        { name: 'Nutella French Toast', price: 450 },
      ]
    },
    {
      title: 'Cold Coffee Bhi hai...',
      items: [
        { name: 'Iced Latte', price: 499 },
        { name: 'Iced Carmel Latte', price: 550 },
        { name: 'Iced Mocha', price: 550 },
        { name: 'Iced Cappuccino', price: 550 },
        { name: 'Iced Vanilla Coffee', price: 599 },
        { name: 'Iced Chocolate Mocha', price: 650 },
      ]
    },
    {
      title: 'Thandi Chai',
      items: [
        { name: 'Lemon Tea', price: 250 },
        { name: 'Peach Tea', price: 250 },
        { name: 'Strawberry Tea', price: 250 },
      ]
    },
    {
      title: 'Ice Cream Shakes',
      items: [
        { name: 'Mango', price: 450 },
        { name: 'Vanilla', price: 450 },
        { name: 'Orio', price: 450 },
        { name: 'Strawberry', price: 450 },
        { name: 'Chocolate', price: 499 },
        { name: 'Strawberry Banana', price: 499 },
      ]
    },
    {
      title: 'Bhookh Lagi hai...',
      items: [
        { name: 'Plain Fries', price: 299 },
        { name: 'Masala Fries', price: 350 },
        { name: 'Loaded Fries', price: 490 },
        { name: 'Chicken Loaded Fries', price: 570 },
        { name: 'Chicken Cheese Loaded Fries', price: 899 },
        { name: 'Nuggets 6 pc', price: 399 },
      ]
    },
    {
      title: 'Wraps',
      items: [
        { name: 'Chicken kebab', price: 350 },
        { name: 'BBQ Tikka', price: 450 },
        { name: 'Malai Boti', price: 490 },
        { name: 'Chicken Tandoori', price: 490 },
        { name: 'Chicken Cheese Kebab', price: 450 },
        { name: 'Tandoori Garlic Mayo', price: 520 },
      ]
    },
    {
      title: 'Margarita',
      items: [
        { name: 'Mint Margarita', price: 250 },
        { name: 'Gava Margarita', price: 350 },
        { name: 'Pineapple Margarita', price: 450 },
        { name: 'Lychee Margarita', price: 450 },
      ]
    },
    {
      title: 'Beverages',
      items: [
        { name: 'Cold Drink 350ml', price: 100 },
        { name: 'Cold Drink 500ml', price: 130 },
        { name: 'Cold Drink 1.5ltr', price: 250 },
        { name: 'Water Small 500ml', price: 80 },
      ]
    }
  ];
}
